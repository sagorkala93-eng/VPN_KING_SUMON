# Simple BD Messenger Bot
A Bangladesh-friendly auto-reply Messenger Bot using Node.js.

## Install
```
npm install
```

## Setup .env
```
VERIFY_TOKEN=your_verify_token_here
PAGE_ACCESS_TOKEN=your_page_access_token_here
```

## Run
```
npm start
```

## Webhook URL
```
https://your-domain.com/webhook
```
